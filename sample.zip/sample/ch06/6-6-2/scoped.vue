<template>
  <p class="message">こんにちは！</p>
</template>

<style scoped>
.message { color: #42b983; }
</style>
